import 'package:flutter/material.dart';

const kFirstColor = Color(0xFF00aaff);
const kSecondColor = Color(0xFF232441);
const kThirdColor = Color(0xFF131429);
